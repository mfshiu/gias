# PromptRegistry：載入/版本/模板渲染
