# Prompt 資產化：name + version
# registry.render("intent_parse_v1", **kwargs) 產生 messages
# 模板檔用 .md 方便版本控管與 diff