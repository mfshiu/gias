# src\llm\client.py
# LLMClient：統一呼叫入口（chat/json）
# 唯一對外入口：client.chat() / client.json()
# 統一處理：timeout、重試、provider 呼叫、回傳標準結果（含 token/cost）

class LLMClient:
    def __init__(self, provider_client):
        self.provider_client = provider_client

    def chat(self, messages, **kwargs):
        return self.provider_client.chat(messages, **kwargs)

    def json(self, messages, schema, **kwargs):
        response = self.provider_client.chat(messages, **kwargs)
        # 假設 response.content 是模型回傳的文字
        # 這裡應該有 JSON 解析與 schema 驗證的邏輯
        parsed_response = self._parse_and_validate(response.content, schema)
        return parsed_response

    def _parse_and_validate(self, content, schema):
        # 這裡放解析 JSON 並驗證 schema 的邏輯
        pass
    
llm_client = LLMClient(provider_client=None)  # 這裡的 provider_client 應該是具體的 LLM 提供者實作

    