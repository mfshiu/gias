# BaseProvider：抽象介面
