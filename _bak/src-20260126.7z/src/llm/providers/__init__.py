# 把不同 LLM 實作隔離（OpenAI / 本地 Ollama / 其他）
# 代理與任務層完全不碰各家 SDK