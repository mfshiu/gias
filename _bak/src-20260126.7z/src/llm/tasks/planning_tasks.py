# decompose_intent(), draft_plan()
