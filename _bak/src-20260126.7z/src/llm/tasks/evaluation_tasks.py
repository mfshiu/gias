# evaluate_item()
